import fs from 'node:fs/promises'
import http from 'node:http'
import os from 'node:os'
import path from 'node:path'
import { chromium } from 'playwright'

const extensionPath = '/Users/wangzhijie/Documents/GitHub/DeepL/Linswift/chrome-extension'
const articlePath = '/Users/wangzhijie/Documents/GitHub/DeepL/Linswift/chrome-extension/e2e/article.html'
const outDir = '/tmp/linswift-ext-debug'

async function serveFixture() {
  const html = await fs.readFile(articlePath, 'utf8')

  return new Promise((resolve) => {
    const server = http.createServer((request, response) => {
      if (request.url === '/article.html') {
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
        response.end(html)
        return
      }

      response.writeHead(404)
      response.end('not found')
    })

    server.listen(0, '127.0.0.1', () => {
      const address = server.address()
      resolve({
        server,
        url: `http://127.0.0.1:${address.port}/article.html`,
      })
    })
  })
}

const fixture = await serveFixture()
await fs.mkdir(outDir, { recursive: true })
const userDataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'linswift-ext-debug-'))
const context = await chromium.launchPersistentContext(userDataDir, {
  headless: false,
  args: [
    `--disable-extensions-except=${extensionPath}`,
    `--load-extension=${extensionPath}`,
  ],
})

try {
  const page = await context.newPage()
  page.on('console', (message) => console.log(`[page:${message.type()}] ${message.text()}`))
  page.on('pageerror', (error) => console.log(`[pageerror] ${error.message}`))

  await page.goto(fixture.url, { waitUntil: 'networkidle' })
  const panelLocator = page.locator('#linswift-floating-root .linswift-panel')
  try {
    await panelLocator.waitFor({ state: 'visible', timeout: 15000 })
  } catch (error) {
    const diagnostics = await page.evaluate(() => ({
      hasContentScriptFlag: Boolean(window.__LINSWIFT_CONTENT_SCRIPT__),
      hasRoot: Boolean(document.getElementById('linswift-floating-root')),
      rootMarkup: document.getElementById('linswift-floating-root')?.outerHTML || null,
      bodyPreview: document.body.innerText.slice(0, 300),
    }))
    console.log(JSON.stringify({ diagnostics }, null, 2))
    throw error
  }

  await page.screenshot({ path: path.join(outDir, 'translate.png'), fullPage: true })
  const translateText = await page.locator('#linswift-floating-root .linswift-panel').innerText()

  await page.evaluate(() => {
    const paragraph = document.querySelectorAll('p')[1]
    const textNode = paragraph?.firstChild
    if (!textNode || textNode.nodeType !== Node.TEXT_NODE) {
      throw new Error('missing sentence text node')
    }

    const rawText = textNode.textContent || ''
    const target = 'Because the terminology was unusually ornate and the argument remained implicit for several paragraphs'
    const start = rawText.indexOf(target)
    if (start < 0) {
      throw new Error('missing target sentence')
    }

    const selection = window.getSelection()
    const range = document.createRange()
    range.setStart(textNode, start)
    range.setEnd(textNode, start + target.length)
    selection?.removeAllRanges()
    selection?.addRange(range)
    document.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }))
  })
  await page.waitForTimeout(1800)
  const sentenceVisible = await page
    .locator("#linswift-floating-root [data-sentence-popup]")
    .evaluate((el) => !el.classList.contains('linswift-hidden'))
  await page.waitForFunction(() => {
    const popup = document.querySelector("[data-sentence-popup]")
    return popup && !popup.classList.contains('linswift-hidden') && popup.textContent.includes('中文翻译')
  }, { timeout: 15000 })
  const sentenceText = await page
    .locator("#linswift-floating-root [data-sentence-popup]")
    .innerText()
  await page.screenshot({ path: path.join(outDir, 'sentence.png'), fullPage: true })

  await page.locator('#linswift-floating-root [data-panel-view="settings"]').click()
  await page.waitForTimeout(500)
  const settingsText = await page
    .locator("#linswift-floating-root [data-panel-page='settings']")
    .innerText()
  await page.screenshot({ path: path.join(outDir, 'settings.png'), fullPage: true })

  console.log(
    JSON.stringify(
      {
        outDir,
        url: fixture.url,
        sentenceVisible,
        translateText,
        sentenceText,
        settingsText,
      },
      null,
      2
    )
  )
} finally {
  await context.close()
  fixture.server.close()
}
