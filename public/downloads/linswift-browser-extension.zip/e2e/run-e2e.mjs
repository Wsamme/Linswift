import fs from 'node:fs/promises'
import http from 'node:http'
import os from 'node:os'
import path from 'node:path'
import { chromium } from 'playwright'

const extensionPath = '/Users/wangzhijie/Documents/GitHub/DeepL/Linswift/chrome-extension'
const articlePath = '/Users/wangzhijie/Documents/GitHub/DeepL/Linswift/chrome-extension/e2e/article.html'
const loginEmail = process.env.LINSWIFT_TEST_EMAIL || 'codex.test.20260312.1@gmail.com'
const loginPassword = process.env.LINSWIFT_TEST_PASSWORD || 'Linswift#2026!'

async function serveFixture() {
  const html = await fs.readFile(articlePath, 'utf8')

  return new Promise((resolve) => {
    const server = http.createServer((request, response) => {
      if (request.url === '/article.html') {
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
        response.end(html)
        return
      }

      response.writeHead(404)
      response.end('not found')
    })

    server.listen(0, '127.0.0.1', () => {
      const address = server.address()
      resolve({
        server,
        url: `http://127.0.0.1:${address.port}/article.html`,
      })
    })
  })
}

const { server, url } = await serveFixture()
const userDataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'linswift-ext-e2e-'))
const browserExecutable = process.env.LINSWIFT_E2E_BROWSER === 'system-chrome'
  ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
  : chromium.executablePath()

let context

try {
  context = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    executablePath: browserExecutable,
    args: [
      `--disable-extensions-except=${extensionPath}`,
      `--load-extension=${extensionPath}`,
    ],
  })

  const articlePage = await context.newPage()
  articlePage.on('console', (message) => {
    console.log(`[page:${message.type()}] ${message.text()}`)
  })
  articlePage.on('pageerror', (error) => {
    console.log(`[pageerror] ${error.message}`)
  })
  await articlePage.goto(url, { waitUntil: 'networkidle' })

  const panelRoot = articlePage.locator('#linswift-floating-root')
  const panel = articlePage.locator('#linswift-floating-root .linswift-panel')
  const bubble = articlePage.locator('#linswift-floating-root .linswift-bubble')
  const scanButton = articlePage.locator('#linswift-floating-root [data-scan-button]')
  const resultsList = articlePage.locator('#linswift-floating-root [data-results-list]')
  const minimizeButton = articlePage.locator('#linswift-floating-root .linswift-minimize')
  const settingsToggle = articlePage.locator('#linswift-floating-root [data-panel-view="settings"]')
  const translateToggle = articlePage.locator('#linswift-floating-root [data-panel-view="translate"]')
  const sentencePopup = articlePage.locator("#linswift-floating-root [data-sentence-popup]")
  const inlineToggle = articlePage.locator('#linswift-floating-root [data-inline-toggle]')
  const loginPage = articlePage.locator('#linswift-floating-root [data-panel-page="login"]')
  const emailInput = articlePage.locator('#linswift-floating-root [data-auth-email]')
  const passwordInput = articlePage.locator('#linswift-floating-root [data-auth-password]')
  const loginSubmit = articlePage.locator('#linswift-floating-root [data-auth-action="signin"]')

  try {
    await panelRoot.waitFor({ state: 'visible', timeout: 15000 })
  } catch (error) {
    const diagnostics = await articlePage.evaluate(() => ({
      hasContentScriptFlag: Boolean(window.__LINSWIFT_CONTENT_SCRIPT__),
      hasRoot: Boolean(document.getElementById('linswift-floating-root')),
      rootMarkup: document.getElementById('linswift-floating-root')?.outerHTML || null,
      bodyPreview: document.body.innerText.slice(0, 200),
    }))
    console.log(JSON.stringify({ diagnostics }, null, 2))
    throw error
  }
  await panel.waitFor({ state: 'visible', timeout: 15000 })

  if (await loginPage.isVisible()) {
    await emailInput.fill(loginEmail)
    await passwordInput.fill(loginPassword)
    await loginSubmit.click()
    await scanButton.waitFor({ state: 'visible', timeout: 20000 })
  }

  await articlePage.evaluate(() => {
    const paragraph = document.querySelector('p.lede')
    const textNode = paragraph?.firstChild
    if (!textNode || textNode.nodeType !== Node.TEXT_NODE) {
      throw new Error('missing lede text node')
    }

    const rawText = textNode.textContent || ''
    const start = rawText.indexOf('meticulous')
    if (start < 0) {
      throw new Error('missing target word')
    }

    const selection = window.getSelection()
    const range = document.createRange()
    range.setStart(textNode, start)
    range.setEnd(textNode, start + 'meticulous'.length)
    selection?.removeAllRanges()
    selection?.addRange(range)
    document.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }))
  })
  await articlePage.locator('.linswift-selection-highlight').first().waitFor({ timeout: 15000 })
  await articlePage.locator('.linswift-word-tooltip:not(.linswift-hidden)').waitFor({ timeout: 15000 })
  const selectionHighlightText = await articlePage.locator('.linswift-selection-highlight').first().innerText()
  const selectionTooltipText = await articlePage.locator('.linswift-word-tooltip').innerText()

  await settingsToggle.click()
  await inlineToggle.waitFor({ timeout: 10000 })
  await inlineToggle.click()
  await translateToggle.click()

  await scanButton.click()
  await resultsList.locator('.linswift-card').first().waitFor({ timeout: 15000 })
  await articlePage.locator('.linswift-inline-translation').first().waitFor({ timeout: 15000 })
  await articlePage.waitForFunction(() => {
    const cards = Array.from(document.querySelectorAll('#linswift-floating-root [data-results-list] .linswift-card'))
    return cards.some((card) => card.textContent?.includes('meticulous'))
      && cards.some((card) => card.textContent?.includes('convoluted'))
  }, { timeout: 15000 })

  const statusText = await articlePage.locator('#linswift-floating-root [data-status]').innerText()
  const scanResultsText = await resultsList.innerText()
  const inlineAnnotationCount = await articlePage.locator('.linswift-inline-annotation').count()

  await resultsList.locator('.linswift-card [data-action="locate"]').first().click()
  await articlePage.waitForTimeout(500)
  const highlightCount = await articlePage.locator('mark.linswift-word-highlight').count()

  await resultsList.locator('.linswift-card [data-action="save"]').first().click()

  await articlePage.evaluate(() => {
    const paragraph = document.querySelectorAll('p')[1]
    if (!paragraph) {
      throw new Error('missing sentence paragraph')
    }
    const selection = window.getSelection()
    const range = document.createRange()
    range.selectNodeContents(paragraph)
    selection?.removeAllRanges()
    selection?.addRange(range)
    document.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 0 }))
  })
  await articlePage.waitForFunction(() => {
    const popup = document.querySelector("[data-sentence-popup]")
    return (
      popup &&
      !popup.classList.contains('linswift-hidden') &&
      popup.textContent.includes('中文翻译')
    )
  }, { timeout: 15000 })
  const sentenceText = await sentencePopup.innerText()
  const sentencePopupBoxBefore = await sentencePopup.boundingBox()
  await articlePage.mouse.move(640, 480)
  await articlePage.waitForTimeout(300)
  const sentencePopupBoxAfter = await sentencePopup.boundingBox()
  const sentencePopupStable =
    sentencePopupBoxBefore &&
    sentencePopupBoxAfter &&
    Math.abs(sentencePopupBoxBefore.x - sentencePopupBoxAfter.x) < 2 &&
    Math.abs(sentencePopupBoxBefore.y - sentencePopupBoxAfter.y) < 2

  await minimizeButton.click()
  await bubble.waitFor({ state: 'visible', timeout: 5000 })
  await bubble.click()
  await panel.waitFor({ state: 'visible', timeout: 5000 })

  const summary = {
    browserExecutable,
    pageUrl: url,
    statusText,
    selectionHighlightText,
    selectionTooltipContainsMeticulous: selectionTooltipText.toLowerCase().includes('meticulous'),
    highlightCount,
    inlineAnnotationCount,
    resultsContainMeticulous: scanResultsText.includes('meticulous'),
    resultsContainConvoluted: scanResultsText.includes('convoluted'),
    sentenceModeOpened: sentenceText.includes('划句'),
    sentenceTranslationWorked: sentenceText.includes('因为术语异常华丽'),
    sentencePopupStable,
    minimizeRestoreWorked: await bubble.isHidden(),
  }

  console.log(JSON.stringify(summary, null, 2))
} finally {
  await context?.close()
  server.close()
}
